namespace FSH.Starter.WebApi.Catalog.Application.Brands.Update.v1;
public sealed record UpdateBrandResponse(Guid? Id);
